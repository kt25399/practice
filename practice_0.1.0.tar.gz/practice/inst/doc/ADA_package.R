## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------

library(tidyverse)
load("~/repos/practice/data/NBA.rda")
load("~/repos/practice/data/NBA_salary.rda")
#lets remove the column "game"

nba <- select(NBA, -Game)

#lets add salary stats
salary <- NBA_salary

nba <- left_join(nba, salary, by = "Name")

#and remove NAs
nba <- nba %>% filter(team != "NA")



## -----------------------------------------------------------------------------

pca <- nba %>%
  select(PTS:PF) %>%
  prcomp(center = TRUE, scale. = TRUE)

summary(pca)


## -----------------------------------------------------------------------------

vars <- dimnames(pca$rotation[, c(1,2,3,4)])[[1]]
head(vars)
 pca$rotation[, c(1,2,3,4)] %>%
  as_tibble %>%
  mutate(variable = vars) %>% # adding a column called 'variable' with the name of the behavior you measured
  gather("PC", "loading", PC1:PC4) %>%
  ggplot(aes(x = variable, y = loading)) +
  geom_col() +
  theme_minimal() +
  facet_wrap(~PC) +
  coord_flip() +
  ggtitle("The loadings of each variable for the first 4 PCs")


## -----------------------------------------------------------------------------

 nba_with_loadings <- nba %>% 
  mutate(PC1 = pca$x[,1],
         PC2 = pca$x[,2],
         PC3 = pca$x[,3],
         PC4 = pca$x[,4])


## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = PC1, y = Rating)) + geom_point() + geom_smooth()

fit <- lm(Rating ~ PC1, data = nba_with_loadings)
summary(fit)


nba_with_loadings %>% ggplot(aes(x = PC2, y = Rating)) + geom_point() + geom_smooth()

fit <- lm(Rating ~ PC2, data = nba_with_loadings)
summary(fit)


nba_with_loadings %>% ggplot(aes(x = PC3, y = Rating)) + geom_point() + geom_smooth()

fit <- lm(Rating ~ PC3, data = nba_with_loadings)
summary(fit)


nba_with_loadings %>% ggplot(aes(x = PC4, y = Rating)) + geom_point() + geom_smooth()

fit <- lm(Rating ~ PC4, data = nba_with_loadings)
summary(fit)



## -----------------------------------------------------------------------------


nba_with_loadings %>% ggplot(aes(x = PC1, y = `MIN.G`)) + geom_point() + geom_smooth()

fit <- lm(`MIN.G` ~ PC1, data = nba_with_loadings)
summary(fit)


## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = PC1, y = salary)) + geom_point() + geom_smooth()

fit <- lm(salary ~ PC1, data = nba_with_loadings)
summary(fit)


## -----------------------------------------------------------------------------

 df_summ <- nba_with_loadings %>%
  group_by(Pos) %>%
  summarise(pca1_avg = mean(PC1), pca2_avg = mean(PC2), pca3_avg = mean(PC3), pca4_avg = mean(PC4))


## -----------------------------------------------------------------------------

nba_with_loadings %>%
  ggplot(aes(x = PC1, y = PC2, color = Pos)) +
  geom_point(data = df_summ, aes(x = pca1_avg, y = pca2_avg, color = Pos), size = 5) +
  theme_minimal() +
  stat_ellipse() +
  ggtitle("Plot of PCA 1 vs. 2 loadings for NBA players ",
          subtitle = "Large points are the centroids for each position") 


## -----------------------------------------------------------------------------

nba_with_loadings %>%
  ggplot(aes(x = PC2, y = PC3, color = Pos)) +
  geom_point(data = df_summ, aes(x = pca2_avg, y = pca3_avg, color = Pos), size = 5) +
  theme_minimal() +
  stat_ellipse() +
  ggtitle("Plot of PCA 2 vs. 3 loadings for NBA players ",
          subtitle = "Large points are the centroids for each position") 


## -----------------------------------------------------------------------------

nba_with_loadings %>%
  ggplot(aes(x = PC3, y = PC4, color = Pos)) +
  geom_point(data = df_summ, aes(x = pca3_avg, y = pca4_avg, color = Pos), size = 5) +
  theme_minimal() +
  stat_ellipse() +
  ggtitle("Plot of PCA 1 vs. 3 loadings for NBA players ",
          subtitle = "Large points are the centroids for each position") 

## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = Pos, y = PC1, color = Pos)) + geom_point() + geom_boxplot()
fit <- lm(PC1 ~ Pos, data = nba_with_loadings)
summary(fit)


## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = Pos, y = PC2, color = Pos)) + geom_point() + geom_boxplot()
fit <- aov(PC2 ~ Pos, data = nba_with_loadings)
summary(fit)
TukeyHSD(fit)


## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = Pos, y = PC3, color = Pos)) + geom_point() + geom_boxplot()
fit <- aov(PC3 ~ Pos, data = nba_with_loadings)
summary(fit)
TukeyHSD(fit)


## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = Pos, y = PC4, color = Pos)) + geom_point() + geom_boxplot()
fit <- aov(PC4 ~ Pos, data = nba_with_loadings)
summary(fit)


