## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include = FALSE---------------------------------------------------
library(practice)
library(tidyverse)
library(cluster)
library(factoextra)

## ----dataframes---------------------------------------------------------------
load("~/repos/practice/data/NBA.rda")
head(NBA)
load("~/repos/practice/data/NBA_salary.rda")
head(NBA_salary)

## ----optimal_cluster showcase-------------------------------------------------
op <- optimal_cluster(iris)

## ----elbow--------------------------------------------------------------------
op[[1]]

## ----silhouette---------------------------------------------------------------
op[[2]]

## ----gap----------------------------------------------------------------------
op[[3]]

## ----visualization showcase---------------------------------------------------
visualization(d = iris, n = 2:3)

## ----PCA showcase-------------------------------------------------------------
p <- PCA(d = iris, group = iris$Species)

## ----summary------------------------------------------------------------------
p[[2]]

## ----PCA plot-----------------------------------------------------------------
p[[4]]

## ----rating factor------------------------------------------------------------
NBA_f <- NBA %>% mutate(Rating = case_when(Rating < 80 ~ 1,
                                    Rating >= 80 & Rating < 90 ~ 2,
                                    Rating >= 90 ~ 3))
NBA_f <- NBA_f %>% mutate(Rating = factor(Rating, levels = c(1, 2, 3),
                                        labels = c("low", "medium", "high")))

## ----NBA optimal--------------------------------------------------------------
optimal_cluster(NBA_f)

## ----NBA visualize------------------------------------------------------------
visualization(NBA_f, n = 1:4)

## ----PCA----------------------------------------------------------------------
PCA(NBA_f, group = NBA_f$Pos)
PCA(NBA_f, group = NBA_f$Rating)

## ----adding salary------------------------------------------------------------
NBA_salary2 <- NBA_salary %>% select(Name, salary)
NBA2 <- left_join(NBA[-4], NBA_salary2, by = "Name")
NBA2 <- na.omit(NBA2)
NBA_f <- left_join(NBA_f[-4], NBA_salary2)
NBA_f <- NBA_f %>% mutate(salary = case_when(salary < 1000000 ~ 1,
                                    salary >= 1000000 & salary < 10000000 ~ 2,
                                    salary >= 10000000 ~ 3))
NBA_f <- NBA_f %>% mutate(salary = factor(salary, levels = c(1, 2, 3),
                                        labels = c("low", "medium", "high")))
NBA_f <- na.omit(NBA2)

PCA(NBA_f, group = NBA_f$salary)

## ----PCA then k-cluster-------------------------------------------------------
###PCA then k-cluster
PCANBA <- PCA(NBA_f, group = NBA2$Pos)
NBA3 <- cbind(NBA_f, PCANBA[[2]][[5]])

optimal_cluster(NBA3[, -4:-14])
visualization(NBA3[, -4:-14], n = 1:4)


## -----------------------------------------------------------------------------

p <- NBA_f %>%
  select(PTS:PF) %>%
  PCA(group = Rating)


## -----------------------------------------------------------------------------

vars <- dimnames(p[[5]]$rotation[, c(1,2,3,4)])[[1]]
head(vars)
 p[[5]]$rotation[, c(1,2,3,4)] %>%
  as_tibble %>%
  mutate(variable = vars) %>% # adding a column called 'variable' with the name of the behavior you measured
  gather("PC", "loading", PC1:PC4) %>%
  ggplot(aes(x = variable, y = loading)) +
  geom_col() +
  theme_minimal() +
  facet_wrap(~PC) +
  coord_flip() +
  ggtitle("The loadings of each variable for the first 4 PCs")


## -----------------------------------------------------------------------------

nba_with_loadings <- cbind(NBA2[1:4], p[[6]])
nba_with_loadings <- cbind(nba_with_loadings, NBA2[17])

## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = PC1, y = Rating)) + geom_point() + geom_smooth()

fit <- lm(Rating ~ PC1, data = nba_with_loadings)
summary(fit)


nba_with_loadings %>% ggplot(aes(x = PC2, y = Rating)) + geom_point() + geom_smooth()

fit <- lm(Rating ~ PC2, data = nba_with_loadings)
summary(fit)


nba_with_loadings %>% ggplot(aes(x = PC3, y = Rating)) + geom_point() + geom_smooth()

fit <- lm(Rating ~ PC3, data = nba_with_loadings)
summary(fit)


nba_with_loadings %>% ggplot(aes(x = PC4, y = Rating)) + geom_point() + geom_smooth()

fit <- lm(Rating ~ PC4, data = nba_with_loadings)
summary(fit)



## -----------------------------------------------------------------------------


nba_with_loadings %>% ggplot(aes(x = PC1, y = `MIN.G`)) + geom_point() + geom_smooth()

fit <- lm(`MIN.G` ~ PC1, data = nba_with_loadings)
summary(fit)


## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = PC1, y = salary)) + geom_point() + geom_smooth()

fit <- lm(salary ~ PC1, data = nba_with_loadings)
summary(fit)


## -----------------------------------------------------------------------------

 df_summ <- nba_with_loadings %>%
  group_by(Pos) %>%
  summarise(pca1_avg = mean(PC1), pca2_avg = mean(PC2), pca3_avg = mean(PC3), pca4_avg = mean(PC4))


## -----------------------------------------------------------------------------

nba_with_loadings %>%
  ggplot(aes(x = PC1, y = PC2, color = Pos)) +
  geom_point(data = df_summ, aes(x = pca1_avg, y = pca2_avg, color = Pos), size = 5) +
  theme_minimal() +
  stat_ellipse() +
  ggtitle("Plot of PCA 1 vs. 2 loadings for NBA players ",
          subtitle = "Large points are the centroids for each position") 


## -----------------------------------------------------------------------------

nba_with_loadings %>%
  ggplot(aes(x = PC2, y = PC3, color = Pos)) +
  geom_point(data = df_summ, aes(x = pca2_avg, y = pca3_avg, color = Pos), size = 5) +
  theme_minimal() +
  stat_ellipse() +
  ggtitle("Plot of PCA 2 vs. 3 loadings for NBA players ",
          subtitle = "Large points are the centroids for each position") 


## -----------------------------------------------------------------------------

nba_with_loadings %>%
  ggplot(aes(x = PC3, y = PC4, color = Pos)) +
  geom_point(data = df_summ, aes(x = pca3_avg, y = pca4_avg, color = Pos), size = 5) +
  theme_minimal() +
  stat_ellipse() +
  ggtitle("Plot of PCA 1 vs. 3 loadings for NBA players ",
          subtitle = "Large points are the centroids for each position") 

## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = Pos, y = PC1, color = Pos)) + geom_point() + geom_boxplot()
fit <- lm(PC1 ~ Pos, data = nba_with_loadings)
summary(fit)


## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = Pos, y = PC2, color = Pos)) + geom_point() + geom_boxplot()
fit <- aov(PC2 ~ Pos, data = nba_with_loadings)
summary(fit)
TukeyHSD(fit)


## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = Pos, y = PC3, color = Pos)) + geom_point() + geom_boxplot()
fit <- aov(PC3 ~ Pos, data = nba_with_loadings)
summary(fit)
TukeyHSD(fit)


## -----------------------------------------------------------------------------

nba_with_loadings %>% ggplot(aes(x = Pos, y = PC4, color = Pos)) + geom_point() + geom_boxplot()
fit <- aov(PC4 ~ Pos, data = nba_with_loadings)
summary(fit)


