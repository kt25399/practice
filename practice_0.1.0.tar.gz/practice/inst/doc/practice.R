## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include = FALSE---------------------------------------------------
library(practice)
library(tidyverse)
library(cluster)
library(factoextra)

## ----dataframes---------------------------------------------------------------
load("~/repos/practice/data/NBA.rda")
head(NBA)
load("~/repos/practice/data/NBA_salary.rda")
head(NBA_salary)

## ----optimal_cluster showcase-------------------------------------------------
op <- optimal_cluster(iris)

## ----elbow--------------------------------------------------------------------
op[[1]]

## ----silhouette---------------------------------------------------------------
op[[2]]

## ----gap----------------------------------------------------------------------
op[[3]]

## ----visualization showcase---------------------------------------------------
visualization(d = iris, n = 2:3)

## ----PCA showcase-------------------------------------------------------------
p <- PCA(d = iris, group = iris$Species)

## ----summary------------------------------------------------------------------
p[[2]]

## ----PCA plot-----------------------------------------------------------------
p[[4]]

## ----rating factor------------------------------------------------------------
NBA2 <- NBA %>% mutate(Rating = case_when(Rating < 80 ~ 1,
                                    Rating >= 80 & Rating < 90 ~ 2,
                                    Rating >= 90 ~ 3))
NBA2 <- NBA2 %>% mutate(Rating = factor(Rating, levels = c(1, 2, 3),
                                        labels = c("low", "medium", "high")))

## ----NBA optimal--------------------------------------------------------------
optimal_cluster(NBA2)

## ----NBA visualize------------------------------------------------------------
visualization(NBA2, n = 1:4)

## ----PCA----------------------------------------------------------------------
PCA(NBA2, group = NBA2$Pos)
PCA(NBA2, group = NBA2$Rating)

## ----adding salary------------------------------------------------------------
NBA_salary2 <- NBA_salary %>% select(Name, salary)
NBA2 <- left_join(NBA2, NBA_salary2, by = "Name")
NBA2 <- NBA2[-4]
NBA2 <- NBA2 %>% mutate(salary = case_when(salary < 1000000 ~ 1,
                                    salary >= 1000000 & salary < 10000000 ~ 2,
                                    salary >= 10000000 ~ 3))
NBA2 <- NBA2 %>% mutate(salary = factor(salary, levels = c(1, 2, 3),
                                        labels = c("low", "medium", "high")))
NBA2 <- na.omit(NBA2)

PCA(NBA2, group = NBA2$salary)

## ----PCA then k-cluster-------------------------------------------------------
###PCA then k-cluster
PCANBA <- PCA(NBA2, group = NBA2$Pos)
NBA3 <- cbind(NBA2, PCANBA[[2]][[5]])

optimal_cluster(NBA3[, -4:-14])
visualization(NBA3[, -4:-14], n = 1:4)


